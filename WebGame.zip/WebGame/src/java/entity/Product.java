/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entity;

/**
 *
 * @author VXH
 */
public class Product {
    private int idp;
    private String description;
    private String rank;
    private String ngoc;
    private String tuong;
    private String trangphuc;
    private String loainick;
    private int price;

    public Product() {
    }

    public Product(int idp, String description, String rank, String ngoc, String tuong, String trangphuc, String loainick, int price) {
        this.idp = idp;
        this.description = description;
        this.rank = rank;
        this.ngoc = ngoc;
        this.tuong = tuong;
        this.trangphuc = trangphuc;
        this.loainick = loainick;
        this.price = price;
    }

    public int getIdp() {
        return idp;
    }

    public void setIdp(int idp) {
        this.idp = idp;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getRank() {
        return rank;
    }

    public void setRank(String rank) {
        this.rank = rank;
    }

    public String getNgoc() {
        return ngoc;
    }

    public void setNgoc(String ngoc) {
        this.ngoc = ngoc;
    }

    public String getTuong() {
        return tuong;
    }

    public void setTuong(String tuong) {
        this.tuong = tuong;
    }

    public String getTrangphuc() {
        return trangphuc;
    }

    public void setTrangphuc(String trangphuc) {
        this.trangphuc = trangphuc;
    }

    public String getLoainick() {
        return loainick;
    }

    public void setLoainick(String loainick) {
        this.loainick = loainick;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    @Override
    public String toString() {
        return "Product{" + "idp=" + idp + ", description=" + description + ", rank=" + rank + ", ngoc=" + ngoc + ", tuong=" + tuong + ", trangphuc=" + trangphuc + ", loainick=" + loainick + ", price=" + price + '}';
    }
    
}
